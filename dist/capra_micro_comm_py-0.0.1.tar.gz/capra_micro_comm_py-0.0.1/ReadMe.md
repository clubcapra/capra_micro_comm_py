# capra_micro_comm_py

This is the python package for the capra_micro_comm library.

## Installing

Run:
```bash
pip install git+https://github.com/clubcapra/capra_micro_comm_py.git@master
```